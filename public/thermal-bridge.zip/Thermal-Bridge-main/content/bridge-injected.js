'use strict';

(() => {
  if (window.ThermalBridge) return;

  let seq = 0;
  const pending = new Map();

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;

    const data = event.data;
    if (!data || data.source !== 'thermal-bridge-ext') return;

    const item = pending.get(data.id);
    if (!item) return;

    pending.delete(data.id);

    if (data.success === false) {
      item.reject(new Error(data.message || 'ThermalBridge error'));
      return;
    }

    item.resolve(data);
  });

  function call(type, data = {}) {
    return new Promise((resolve, reject) => {
      const id = ++seq;
      pending.set(id, { resolve, reject });

      window.postMessage({ source: 'thermal-bridge-web', id, type, ...data }, '*');

      setTimeout(() => {
        if (!pending.has(id)) return;

        pending.delete(id);
        reject(new Error('ThermalBridge timeout: ekstensi tidak merespons.'));
      }, 15000);
    });
  }

  window.ThermalBridge = {
    connect() {
      return call('CONNECT_DEVICE');
    },
    disconnect() {
      return call('DISCONNECT_DEVICE');
    },
    print(payload) {
      return call('THERMAL_PRINT', { payload });
    },
    raw(bytes) {
      return call('THERMAL_RAW', { bytes: Array.from(bytes || []) });
    },
    status() {
      return call('GET_STATUS');
    },
    version: '1.0.1',
  };
})();
